package smsmaneno;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import net.proteanit.sql.DbUtils;
/**
 * @author Eric Kamunge
 */
public class AccessDatabase implements ActionListener{
    private JFrame mother=new JFrame("Access Database");
    private JTable dataTable=new JTable();
    private JMenuBar mainmenu=new JMenuBar();
    private JTextArea textArea=new JTextArea();
    private JMenu file=new JMenu("File");
    private JMenuItem viewData=new JMenuItem("View");
    private JSplitPane splitter=new JSplitPane();
    private SMS_Active2 smsActive2;
    public AccessDatabase()
  {
    mother.setSize(800,600);
    try
    {
    // mother.setIconImage();
    }
    catch(Exception ex){}
    Container panel=mother.getContentPane();
    mother.setJMenuBar(mainmenu);
    mother.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    textArea.setSize(mother.getWidth(),500);
    textArea.setBackground(Color.gray);
    textArea.setForeground(Color.WHITE);
    viewData.addActionListener(this);
    splitter.setOrientation(JSplitPane.VERTICAL_SPLIT);
    file.add(viewData);
    mainmenu.add(file);
    dataTable.setBorder(BorderFactory.createLoweredBevelBorder());
    dataTable.setAutoCreateRowSorter(true);
    JScrollPane scroll=new JScrollPane(dataTable);
    scroll.setForeground(Color.GREEN);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    splitter.add(scroll,JSplitPane.TOP);
    splitter.add(textArea,JSplitPane.BOTTOM);
    panel.add(splitter);
    dataTable.setAutoCreateColumnsFromModel(true);
    //dataTable.setFillsViewportHeight(true);
    dataTable.setFont(new Font("Sans Serif",Font.PLAIN,12));
    dataTable.setAutoscrolls(true);
    dataTable.setGridColor(Color.blue);
    dataTable.setUpdateSelectionOnSort(true);
  }
public static void main(String[] args)
{
AccessDatabase dbt=new AccessDatabase();
dbt.mother.setVisible(true);
SMS_Active2 smsActive2=new SMS_Active2();
smsActive2.setDaemon(true);
//smsActive2.start();
//smsActive2.run2();
}
    @Override
public void actionPerformed(ActionEvent e) 
{
      if(e.getSource() instanceof JMenuItem)
      {
      JMenuItem menu=(JMenuItem) e.getSource();
      if(menu.equals(viewData))
       {
       // mother.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        String tabnamesms2 = "outBox";
        String pwd = "root";
        String usernamesms = "Admin";
        try 
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            String database = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=\\smstimeltd.mdb;";
            Connection connsms = DriverManager.getConnection(database, usernamesms, pwd);
            Statement stmsmsreplyError = connsms.createStatement();
            String processHostel2Error = "SELECT * FROM " + tabnamesms2 + "";
            ResultSet r = stmsmsreplyError.executeQuery(processHostel2Error);
            dataTable.setModel(DbUtils.resultSetToTableModel(r));
        } 
           catch(Exception ex)
           {
            System.out.println(ex.toString()+""+ex.getMessage());
           }  
       }
      }
    }
}