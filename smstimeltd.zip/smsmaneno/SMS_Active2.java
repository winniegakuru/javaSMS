/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package smsmaneno;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Eric Kamunge
 */
    public class SMS_Active2 extends Thread {
//////////////////////////////////////////////////////////////////////////////////////        
        public void run2() 
        {
            //smsArea.append("runMethod...\n");
            System.out.println("Server Initializing...");
            try 
            {
                //smsArea.append("InsideRunMethod...CurrentThread..." + Thread.currentThread() + "\n");
                System.out.println("Server Running Thread..." + Thread.currentThread());
                while (true) 
                {
                    try 
                    {
                        Thread.sleep(5000);
                        runSql();
                    }
                    catch (Exception t) 
                    {
                        //smsArea.append(t.getMessage());
                        //t.printStackTrace();
                    }
                    System.out.println("Server Running Thread..." + Thread.currentThread());
                }
            } 
            finally 
            {
                //smsArea.append("RunMethodExits...");
                System.out.println("Server Exits Running...");
            }
        }
/////////////////////////////////////////////////////////////////////////////////////////
        public void runSql()
        {
        //setSize(Toolkit.getDefaultToolkit().getScreenSize());
        String tabnamesms2 = "outBox";
        String pwd = "root";
        String usernamesms = "Admin";
        try 
        {
            //Class.forName(driver).newInstance();
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            String database = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=\\smstimeltd.mdb;";
            Connection connsms = DriverManager.getConnection(database, usernamesms, pwd);
            //Connection connsms = DriverManager.getConnection(url + dbName, userName, pswd);
            Statement stmSMS = connsms.createStatement();
            Statement stmsmsreplyError = connsms.createStatement();
            String processHostel2Error = "SELECT * FROM " + tabnamesms2 + "";
            ResultSet r = stmsmsreplyError.executeQuery(processHostel2Error);
            //accessdbtable.setModel(DbUtils.resultSetToTableModel(r));
        } 
        catch (Exception e) 
        {
         System.out.println(e.getMessage());
        }
        }
    }